import { Component } from '@angular/core';

@Component({
  selector: 'ngx-shape-buttons',
  styleUrls: ['./shape-buttons.component.scss'],
  templateUrl: './shape-buttons.component.html',
})
export class ShapeButtonsComponent {
}
